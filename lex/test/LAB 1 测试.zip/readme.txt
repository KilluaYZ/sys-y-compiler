use the executable `check` in linux with options `-s` referring to SysY and `-p` referring to PL0
if you don't have the environment, we also offer you the script and you can use it instead